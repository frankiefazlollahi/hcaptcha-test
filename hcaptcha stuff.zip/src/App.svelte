<script lang="ts" src: string ="https://cdn.jsdelivr.net/npm/vanilla-hcaptcha">
	import LoginForm from './components/LoginForm.svelte'
	import 'vanilla-hcaptcha';

	let color: string = 'blue'
	// function to handle what happens when button is pressed
	const toggle = () => {
		
	}
	
</script>

<main>
	<head>
		<title>hCaptcha Test</title>
		<script src="https://js.hcaptcha.com/1/api.js" async defer></script>

	</head>
	<h1 style="color: {color}">Login Test Page</h1>
	<LoginForm />
	<button on:click={toggle}>Login</button>

	<script src="/node_modules/vanilla-hcaptcha/dist/index.min.js"></script>
	
	

	<button on:click={executeHCaptcha}>
		EXECUTE
	</button>
	<button on:click={resetHCaptcha}>
		RESET
	</button>
	
	<script>
		
	</script>

</main>

<style>
	main {
		text-align: center;
		padding: 1em;
		max-width: 240px;
		margin: 0 auto;
	}

	h1 {
		color: #ff3e00;
		text-transform: uppercase;
		font-size: 4em;
		font-weight: 100;
	}

	@media (min-width: 640px) {
		main {
			max-width: none;
		}
	}
</style>