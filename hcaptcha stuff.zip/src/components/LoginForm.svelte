<script>

</script>

<form>
    <div>
        <label>Username</label>
        <input type="text" name="userName" placeholder="Enter username">
    </div>
    
    <div>
        <label>Password</label>
        <input type="text" name="passWord" placeholder="Enter password"> 
    </div>
</form>